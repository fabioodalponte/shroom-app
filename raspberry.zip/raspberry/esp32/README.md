# ESP32 Firmware (Sala 1)

Arquivo versionado:

1. `sala1_mqtt_bridge.ino`

## Objetivo

1. Ler SHT45 + SCD41.
2. Publicar no MQTT local (Raspberry) em:
   - `tele/chacara/sala1/temp`
   - `tele/chacara/sala1/rh`
   - `tele/chacara/sala1/co2`
   - `tele/chacara/sala1/json`
3. (Opcional) enviar HTTP direto para Supabase.

## Ajustes obrigatorios antes de subir no ESP

Edite no `.ino`:

1. `WIFI_SSID`
2. `WIFI_PASS`
3. `MQTT_HOST`
4. `INGEST_URL` e `SUPABASE_ANON_KEY` se for usar fallback HTTP

## Recomendacao operacional

Com o bridge MQTT->API ativo no Raspberry:

1. Manter `ENABLE_HTTP_FALLBACK 0` para evitar duplicacao e inconsistencias.
2. Mapear no bridge o topico JSON:
   - `tele/chacara/sala1/json -> LOT-2024-001`

## Compatibilidade com o bridge

O bridge aceita `temp`, `rh`, `co2` e faz normalizacao para o payload da API.
